﻿//Declare integer variable and assign it with 254 in hexadecimal representation

using System;

class Hexadecimal254ToInt
{
    static void Main()
    {
        int hexInt = 0xFE;
        Console.WriteLine("The decimal representation of {0:X} is {1}.", hexInt, hexInt);
    }
}
