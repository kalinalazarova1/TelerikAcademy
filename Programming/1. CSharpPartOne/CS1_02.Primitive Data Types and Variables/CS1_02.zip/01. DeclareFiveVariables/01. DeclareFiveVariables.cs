﻿//Declare five variables choosing for each of them the appropriate type to represent
// the following values: 52130, -115, 4825932, 97, -10000

using System;

class DeclareFiveVariables
{
    static void Main()
    {
        ushort a = 52130;
        sbyte b = -115;
        int c = 4825932;
        byte d = 97;
        short e = -10000;
        Console.WriteLine("{0}, {1}, {2}, {3}, {4}", a, b, c, d, e);
    }
}
