﻿using System;

class HelloCSharp   //Create, compile and run "Hello C#" console application
{
    static void Main()
    {
        Console.WriteLine("Hello C#");
    }
}