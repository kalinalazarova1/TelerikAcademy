﻿using System;

class PrintFullName     //Modify the console application to print your name
{
    static void Main()
    {
        Console.WriteLine("Ivan Petrov");
    }
}
