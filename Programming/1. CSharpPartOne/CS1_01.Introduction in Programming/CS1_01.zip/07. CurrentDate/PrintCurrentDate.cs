﻿using System;

class PrintCurrentDate      //Create a console application that prints the current date and time
    {
        static void Main()
        {
            Console.WriteLine(DateTime.Now);
        }
    }
