﻿using System;

class PrintSquareOf12345    //Create application that calculates and prints the square of 12345
{
    static void Main()
    {
        Console.WriteLine("The square of 12345 is: {0}", 12345 * 12345);
    }
}
