﻿namespace StudentCommon
{
    public enum University
    {
        NBU,
        SofiaUniversity,
        UNSS,
        TechnicalUniversity
    }
}
