﻿namespace StudentCommon
{
    public enum Specialty
    {
        Mathematics,
        Informatics,
        SoftwareEngineering,
        Chemistry,
        Physics,
        Geography,
        BulgarianPhylology,
        GermanPhylology,
        EnglishPhylology,
        FrenchPhylology,
        Accounting,
        Finance,
        Insurance,
        BusinessAdministration,
        Law
    }
}
