﻿namespace StudentCommon
{
    public enum Faculty
    {
        Anthropology,
        Archeology,
        Architecture,
        Art,
        Psychology,
        Electronics,
        Design,
        EarthSciences,
        Economics,
        English,
        History,
        Informatics,
        Law,
        Bulgarian,
        Music,
        PhilosophyAndSociology,
        PoliticalSciences,
        PublicAdministration,
        RomanicAndGermanStudies,
        Telecommunications,
        Theatre   
    }
}
