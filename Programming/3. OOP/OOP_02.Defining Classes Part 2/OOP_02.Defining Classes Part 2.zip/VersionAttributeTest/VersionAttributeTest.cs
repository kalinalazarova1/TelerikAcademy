﻿using System;
using System.Runtime.InteropServices;

namespace VersionAttributeTest
{
    public class VersionAttributeTest
    {

    }
}
