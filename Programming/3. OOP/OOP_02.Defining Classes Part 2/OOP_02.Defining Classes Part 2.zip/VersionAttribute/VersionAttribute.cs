﻿using System;

namespace VersionAttribute
{
    class VersionAttribute
    {
        static void Main(string[] args)
        {
        }
    }
}
