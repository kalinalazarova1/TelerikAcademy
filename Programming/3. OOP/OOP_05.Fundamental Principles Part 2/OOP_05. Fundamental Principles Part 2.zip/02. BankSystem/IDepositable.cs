﻿using System;

namespace BankSystem
{
    public interface IDepositable
    {
        void Deposit(decimal amount);
    }
}
