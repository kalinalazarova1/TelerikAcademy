﻿namespace MobilePhone
{
    public enum BatteryType        
    {
        LiIon, NiMH, NiCd
    }
}
